#include <iostream>

int main(int argc, const char *argv[])
{
  const char *name;
  if (argc >= 2) {
    name = argv[1];
  } else {
    name = "World";
  }

  std::cout << "Hello " << name << std::endl;

  return 0;
}
